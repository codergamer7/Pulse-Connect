# Refined Backend (Flask + SQLite)

This backend is shaped to **plug straight into your Vite/React frontend (port 8080)** with simple, RESTful endpoints matching the Applicant → Doctor → Staff workflow, plus digital card and barcode.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

- Backend runs at: **http://localhost:5000**
- Frontend runs at: **http://localhost:8080** (already configured by `vite.config.ts`)
- CORS is opened for `http://localhost:8080`

## Endpoints

### Applicant
- `POST /api/applications` → create application. Body example:
```json
{
  "code": "NHF-ABCD1234",      // optional (frontend may generate); backend will generate if omitted
  "full_name": "John Doe",
  "trn": "123456789",
  "dob": "1990-01-01",
  "gender": "Male",
  "address": "12 Hope Rd",
  "phone": "876-555-0000",
  "parish": "Kingston",
  "condition": "Diabetes Type 2"
}
```
Response: `{ "ok": true, "code": "NHF-XXXXXXX" }`

- `GET /api/applications/:code` → fetch application + certification + approval status

### Doctor
- `POST /api/certifications` → certify an application:
```json
{
  "app_code": "NHF-ABCD1234",
  "doctor_name": "Dr. Sarah Johnson",
  "mcj_reg_no": "MCJ12345",
  "office_address": "456 Medical Plaza",
  "parish": "Kingston",
  "office_phone": "876-555-0200",
  "conditions": [{"name":"Diabetes Type 2","severity":"Moderate"}],
  "notes": "Stable and compliant"
}
```

### Staff
- `POST /api/staff/register`
- `POST /api/staff/login`
- `GET /api/staff/applications` → list with statuses
- `POST /api/staff/approve` with body:
```json
{ "app_code": "NHF-ABCD1234", "action": "approved", "reviewer_username": "admin", "reason": "" }
```
If approved, a **member** is created for digital card.

### Digital Card & Barcode
- `GET /api/members/by-trn/:trn` → fetch member for display on the **Digital Card** component
- `GET /api/barcode/:nhf` → returns a PNG barcode for 12/13-digit NHF numbers

## Frontend wiring (example snippets)

> Applicant submit (in `ApplicationForm.tsx`):

```ts
await fetch("http://localhost:5000/api/applications", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ code, full_name, trn, dob, gender, address, phone, parish, condition }),
}).then(r => r.json());
```

> Doctor certification (in `DoctorCertificationForm.tsx`):

```ts
await fetch("http://localhost:5000/api/certifications", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ app_code: code, doctor_name, mcj_reg_no, conditions, notes, office_address, parish, office_phone }),
}).then(r => r.json());
```

> Staff approvals (in staff dashboard):

```ts
const res = await fetch("http://localhost:5000/api/staff/applications");
const { items } = await res.json();
```

> Digital card fetch:

```ts
const res = await fetch(`http://localhost:5000/api/members/by-trn/${trn}`);
const data = await res.json();
```

> Barcode image tag:

```tsx
<img src={`http://localhost:5000/api/barcode/${nhfDigits}`} alt="NHF barcode" />
```

## Notes
- SQLite file: `app.db` auto-creates on first run.
- Passwords hashed with **bcrypt**.
- Keep this simple schema for hackathon/demo; for production move to Postgres/MySQL and add auth/JWT.
