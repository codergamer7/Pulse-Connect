from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import sqlite3
from io import BytesIO
from pathlib import Path
import bcrypt
import random
from datetime import datetime
import uuid
from barcode import EAN13
from barcode.writer import
def generate_application_code():
    # NHF-YYYYMMDD-XXXXXX (random uppercase letters/digits)
    base = datetime.utcnow().strftime("NHF-%Y%m%d-")
    suffix = "".join(random.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6))
    return base + suffix
 ImageWriter

DB_PATH = Path(__file__).with_name("app.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    # staff users (for admin/staff login)
    cur.execute("""CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash BLOB NOT NULL,
        dob TEXT NOT NULL,
        gender TEXT NOT NULL,
        trn TEXT UNIQUE NOT NULL,
        staff_id TEXT UNIQUE NOT NULL
    )""")
    # applicant applications
    cur.execute("""CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        trn TEXT NOT NULL,
        dob TEXT NOT NULL,
        gender TEXT NOT NULL,
        address TEXT,
        phone TEXT,
        parish TEXT,
        condition TEXT,
        created_at TEXT NOT NULL
    )""")
    # doctor certifications tied to application code
    cur.execute("""CREATE TABLE IF NOT EXISTS certifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        app_code TEXT NOT NULL,
        doctor_name TEXT NOT NULL,
        mcj_reg_no TEXT NOT NULL,
        office_address TEXT,
        parish TEXT,
        office_phone TEXT,
        conditions_json TEXT NOT NULL,
        notes TEXT,
        certification_date TEXT NOT NULL,
        FOREIGN KEY(app_code) REFERENCES applications(code)
    )""")
    # approvals by staff
    cur.execute("""CREATE TABLE IF NOT EXISTS approvals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        app_code TEXT NOT NULL,
        status TEXT NOT NULL, -- 'approved' | 'rejected' | 'pending'
        reviewer_username TEXT,
        reviewed_at TEXT,
        reason TEXT
    )""")
    # minimal members table for digital card (after approval)
    cur.execute("""CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_number TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        trn TEXT UNIQUE NOT NULL,
        valid_from TEXT NOT NULL
    )""")
    conn.commit()
    conn.close()

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": ["http://localhost:8080", "http://127.0.0.1:8080", "http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:3000"]}}, supports_credentials=True)

@app.before_first_request
def _init():
    init_db()

# ---------- Helpers ----------
def json_row(row):
    return {k: row[k] for k in row.keys()}

# ---------- Public API ----------

@app.post("/api/applications")
def create_application():
    data = request.get_json() or {}
    # important fields expected from frontend ApplicationForm
    full_name = data.get("full_name")
    trn = data.get("trn")
    dob = data.get("dob")
    gender = data.get("gender")
    address = data.get("address")
    phone = data.get("phone")
    parish = data.get("parish")
    condition = data.get("condition")
    if not all([full_name, trn, dob, gender]):
        return jsonify({"error": "Missing required fields: full_name, trn, dob, gender"}), 400

    code = None
    if not code:
        # fallback server-side code, UI also generates e.g. NHF-XXXXXX
        code = f"NHF-{abs(hash(full_name + trn + dob)) % 10000000:07d}"
    created_at = datetime.utcnow().isoformat()

    conn = get_db()
    cur = conn.cursor()
    # generate unique application code server-side
    attempts = 0
    code = generate_application_code()
    while True:
        cur.execute("SELECT 1 FROM applications WHERE code=?", (code,))
        if not cur.fetchone():
            break
        code = generate_application_code()
        attempts += 1
        if attempts>10:
            conn.close()
            return jsonify({"error": "Could not generate unique application code"}), 500
    try:
        cur.execute("""INSERT INTO applications(code, full_name, trn, dob, gender, address, phone, parish, condition, created_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (code, full_name, trn, dob, gender, address, phone, parish, condition, created_at))
        # create default pending approval
        cur.execute("""INSERT INTO approvals(app_code, status) VALUES(?, 'pending')""", (code,))
        conn.commit()
    except sqlite3.IntegrityError as e:
        return jsonify({"error": "Application already exists for this code or TRN", "details": str(e)}), 409
    finally:
        conn.close()
    return jsonify({"ok": True, "code": code})

@app.get("/api/applications/<code>")
def get_application(code):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM applications WHERE code = ?", (code,))
    app_row = cur.fetchone()
    if not app_row:
        return jsonify({"error": "Not found"}), 404
    cur.execute("SELECT * FROM certifications WHERE app_code = ?", (code,))
    cert_row = cur.fetchone()
    cur.execute("SELECT * FROM approvals WHERE app_code = ? ORDER BY id DESC LIMIT 1", (code,))
    appr_row = cur.fetchone()
    conn.close()
    return jsonify({
        "application": json_row(app_row),
        "certification": json_row(cert_row) if cert_row else None,
        "approval": json_row(appr_row) if appr_row else {"status": "pending"}
    })

@app.post("/api/certifications")
def create_certification():
    data = request.get_json() or {}
    app_code = data.get("app_code")
    doctor_name = data.get("doctor_name")
    mcj_reg_no = data.get("mcj_reg_no")
    conditions = data.get("conditions", [])
    notes = data.get("notes")
    office_address = data.get("office_address")
    parish = data.get("parish")
    office_phone = data.get("office_phone")
    if not all([app_code, doctor_name, mcj_reg_no]) or not conditions:
        return jsonify({"error": "Missing required certification fields"}), 400

    conn = get_db()
    cur = conn.cursor()
    # ensure app exists
    cur.execute("SELECT 1 FROM applications WHERE code = ?", (app_code,))
    if not cur.fetchone():
        conn.close()
        return jsonify({"error": "Application code not found"}), 404

    certification_date = datetime.utcnow().date().isoformat()
    cur.execute("""INSERT INTO certifications(app_code, doctor_name, mcj_reg_no, office_address, parish, office_phone, conditions_json, notes, certification_date)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (app_code, doctor_name, mcj_reg_no, office_address, parish, office_phone, json.dumps(conditions), notes, certification_date))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

# ---------- Staff endpoints ----------

@app.post("/api/staff/register")
def staff_register():
    data = request.get_json() or {}
    required = ["username", "email", "password", "dob", "gender", "trn", "staff_id"]
    if not all(data.get(k) for k in required):
        return jsonify({"error": "Missing required staff registration fields"}), 400
    pwd_hash = bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt())
    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute("""INSERT INTO staff(username, email, password_hash, dob, gender, trn, staff_id)
                       VALUES(?,?,?,?,?,?,?)""",
                    (data["username"], data["email"], pwd_hash, data["dob"], data["gender"], data["trn"], data["staff_id"]))
        conn.commit()
    except sqlite3.IntegrityError as e:
        return jsonify({"error": "User exists", "details": str(e)}), 409
    finally:
        conn.close()
    return jsonify({"ok": True})

@app.post("/api/staff/login")
def staff_login():
    data = request.get_json() or {}
    user = data.get("username") or data.get("email")
    pwd = data.get("password", "")
    if not user or not pwd:
        return jsonify({"error": "Missing credentials"}), 400
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM staff WHERE username = ? OR email = ?", (user, user))
    row = cur.fetchone()
    conn.close()
    if not row or not bcrypt.checkpw(pwd.encode(), row["password_hash"]):
        return jsonify({"error": "Invalid credentials"}), 401
    return jsonify({"ok": True, "username": row["username"]})

@app.get("/api/staff/applications")
def list_applications():
    """Minimal list view for staff dashboard."""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT a.code, a.full_name, a.trn, a.created_at,
               COALESCE((SELECT status FROM approvals ap WHERE ap.app_code=a.code ORDER BY id DESC LIMIT 1), 'pending') as status
        FROM applications a ORDER BY a.id DESC
    """)
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return jsonify({"items": rows})

@app.post("/api/staff/approve")
def approve_application():
    data = request.get_json() or {}
    app_code = data.get("app_code")
    action = data.get("action")  # 'approved' | 'rejected'
    reviewer = data.get("reviewer_username", "staff")
    reason = data.get("reason")
    if action not in ("approved", "rejected") or not app_code:
        return jsonify({"error": "Invalid action or missing app_code"}), 400

    conn = get_db()
    cur = conn.cursor()
    # ensure exists
    cur.execute("SELECT * FROM applications WHERE code=?", (app_code,))
    app_row = cur.fetchone()
    if not app_row:
        conn.close()
        return jsonify({"error": "Application not found"}), 404

    cur.execute("""INSERT INTO approvals(app_code, status, reviewer_username, reviewed_at, reason)
                   VALUES(?,?,?,?,?)""",
                (app_code, action, reviewer, datetime.utcnow().isoformat(), reason))
    # if approved, create a member record for digital card
    if action == "approved":
        member_number = f"{app_code}".replace("NHF-", "NHF-")  # reuse code as member number
        cur.execute("""INSERT OR IGNORE INTO members(member_number, full_name, trn, valid_from)
                       VALUES(?,?,?,?)""",
                    (member_number, app_row["full_name"], app_row["trn"], datetime.utcnow().date().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

# ---------- Digital card & barcode ----------

@app.get("/api/members/by-trn/<trn>")
def get_member_by_trn(trn):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM members WHERE trn = ?", (trn,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "Member not found"}), 404
    return jsonify(json_row(row))


@app.get("/api/applications")
def list_applications():
    limit = int(request.args.get("limit", 50))
    status = request.args.get("status")  # optional
    conn = get_db()
    cur = conn.cursor()
    if status:
        cur.execute("""SELECT a.code, a.full_name, a.trn, a.dob, a.gender, a.address, a.phone, a.parish, a.condition, a.created_at, COALESCE(ap.status, 'pending') as status
                       FROM applications a
                       LEFT JOIN approvals ap ON ap.app_code = a.code
                       WHERE COALESCE(ap.status, 'pending') = ?
                       ORDER BY datetime(a.created_at) DESC
                       LIMIT ?""", (status, limit))
    else:
        cur.execute("""SELECT a.code, a.full_name, a.trn, a.dob, a.gender, a.address, a.phone, a.parish, a.condition, a.created_at, COALESCE(ap.status, 'pending') as status
                       FROM applications a
                       LEFT JOIN approvals ap ON ap.app_code = a.code
                       ORDER BY datetime(a.created_at) DESC
                       LIMIT ?""", (limit,))
    rows = [dict(zip([c[0] for c in cur.description], r)) for r in cur.fetchall()]
    conn.close()
    return jsonify({"applications": rows})

@app.get("/api/barcode/<nhf>")
def barcode(nhf):
    # Accept 12 or 13 digits; strip non-digits
    digits = "".join(ch for ch in str(nhf) if ch.isdigit())
    if len(digits) not in (12, 13):
        return jsonify({"error": "NHF number must contain 12 or 13 digits"}), 400
    ean = EAN13(digits, writer=ImageWriter())
    buf = BytesIO()
    ean.write(buf)
    buf.seek(0)
    return send_file(buf, mimetype="image/png", download_name=f"{digits}.png")

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
