import { Routes, Route, Navigate } from "react-router-dom";
import { useEffect } from "react";

import Login from "./pages/Login";
import Register from "./pages/Register";
import ApplicantPortal from "./pages/ApplicantPortal";
import DoctorPortal from "./pages/DoctorPortal";
import StaffPortal from "./pages/StaffPortal";

// ======================================================
// 🔐 ProtectedRoute — prevents bypassing login
// ======================================================
const ProtectedRoute = ({ children, allowedRoles }) => {
  const storedUser = localStorage.getItem("user");
  const user = storedUser ? JSON.parse(storedUser) : null;

  // Not logged in → redirect to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Logged in but wrong role → redirect to login
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

// ======================================================
// 🚀 Main App Router
// ======================================================
function App() {
  // Optional: scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Applicant portal */}
      <Route
        path="/applicant"
        element={
          <ProtectedRoute allowedRoles={["applicant"]}>
            <ApplicantPortal />
          </ProtectedRoute>
        }
      />

      {/* Doctor portal */}
      <Route
        path="/doctor"
        element={
          <ProtectedRoute allowedRoles={["doctor"]}>
            <DoctorPortal />
          </ProtectedRoute>
        }
      />

      {/* Staff portal */}
      <Route
        path="/staff"
        element={
          <ProtectedRoute allowedRoles={["staff"]}>
            <StaffPortal />
          </ProtectedRoute>
        }
      />

      {/* Catch-all */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

export default App;
