import sqlite3
from pathlib import Path

db_path = Path(__file__).parent / "app.db"

if not db_path.exists():
    print("❌ Database file not found:", db_path)
else:
    print("✅ Using database:", db_path)

conn = sqlite3.connect(db_path)
cur = conn.cursor()

# List all tables
cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = [r[0] for r in cur.fetchall()]
print("\n📋 Tables in DB:", tables)

# Show applications
if "certifications" in tables:
    print("\n🧾 Applications:")
    for row in cur.execute("SELECT app_code, doctor_name FROM certifications;"):
        print("  ", row)
else:
    print("\n⚠️ No 'applications' table found.")

conn.close()
