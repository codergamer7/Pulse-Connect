from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import sqlite3
from io import BytesIO
from pathlib import Path
import bcrypt
import random
from datetime import datetime
from barcode import EAN13
from barcode.writer import *

# ---------- Utility ----------
def generate_application_code():
    base = datetime.utcnow().strftime("NHF-%Y%m%d-")
    suffix = "".join(random.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6))
    return base + suffix

DB_PATH = Path(__file__).with_name("app.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ---------- Database ----------
def init_db():
    conn = get_db()
    cur = conn.cursor()

    # === USER SYSTEM (new) ===
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash BLOB NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('applicant', 'doctor', 'staff')),
        created_at TEXT NOT NULL
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS applicants (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        full_name TEXT NOT NULL,
        trn TEXT UNIQUE NOT NULL,
        dob TEXT NOT NULL,
        gender TEXT NOT NULL,
        address TEXT,
        phone TEXT,
        parish TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS doctors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        full_name TEXT NOT NULL,
        mcj_reg_no TEXT UNIQUE NOT NULL,
        phone TEXT,
        parish TEXT,
        office_address TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )""")

    # === Existing tables ===
    cur.execute("""CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash BLOB NOT NULL,
        dob TEXT NOT NULL,
        gender TEXT NOT NULL,
        trn TEXT UNIQUE NOT NULL,
        staff_id TEXT UNIQUE NOT NULL
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        trn TEXT NOT NULL,
        dob TEXT NOT NULL,
        gender TEXT NOT NULL,
        address TEXT,
        phone TEXT,
        parish TEXT,
        condition TEXT,
        created_at TEXT NOT NULL
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS certifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        app_code TEXT NOT NULL,
        doctor_name TEXT NOT NULL,
        mcj_reg_no TEXT NOT NULL,
        office_address TEXT,
        parish TEXT,
        office_phone TEXT,
        conditions_json TEXT NOT NULL,
        notes TEXT,
        certification_date TEXT NOT NULL,
        FOREIGN KEY(app_code) REFERENCES applications(code)
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS approvals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        app_code TEXT NOT NULL,
        status TEXT NOT NULL,
        reviewer_username TEXT,
        reviewed_at TEXT,
        reason TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_number TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        trn TEXT UNIQUE NOT NULL,
        valid_from TEXT NOT NULL
    )""")

    conn.commit()
    conn.close()

# ---------- Flask setup ----------
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": ["http://localhost:8080", "http://127.0.0.1:8080", "http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:3000"]}}, supports_credentials=True)

@app.before_request
def _init():
    init_db()

# ---------- Helpers ----------
def json_row(row):
    return {k: row[k] for k in row.keys()}

def user_exists(username, email):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM users WHERE username=? OR email=?", (username, email))
    exists = cur.fetchone() is not None
    conn.close()
    return exists



@app.get("/api/applications")
def list_applications():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM applications ORDER BY created_at DESC")
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return jsonify(rows)

# ---------- Universal Registration ----------
@app.post("/api/applicants/register")
def register_applicant():
    data = request.get_json() or {}
    required = ["username", "email", "password", "full_name", "trn", "dob", "gender"]
    if not all(data.get(k) for k in required):
        return jsonify({"error": "Missing required applicant fields"}), 400

    if user_exists(data["username"], data["email"]):
        return jsonify({"error": "Account already exists with another role"}), 400

    pwd_hash = bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt())
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (username, email, password_hash, role, created_at) VALUES (?, ?, ?, 'applicant', ?)",
        (data["username"], data["email"], pwd_hash, datetime.utcnow().isoformat()),
    )
    user_id = cur.lastrowid

    cur.execute(
        """INSERT INTO applicants (user_id, full_name, trn, dob, gender, address, phone, parish)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            user_id,
            data["full_name"],
            data["trn"],
            data["dob"],
            data["gender"],
            data.get("address"),
            data.get("phone"),
            data.get("parish"),
        ),
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "role": "applicant"})

@app.post("/api/doctor/register")
def register_doctor():
    data = request.get_json() or {}
    required = ["username", "email", "password", "full_name", "mcj_reg_no"]
    if not all(data.get(k) for k in required):
        return jsonify({"error": "Missing required doctor fields"}), 400

    if user_exists(data["username"], data["email"]):
        return jsonify({"error": "Account already exists with another role"}), 400

    pwd_hash = bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt())
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (username, email, password_hash, role, created_at) VALUES (?, ?, ?, 'doctor', ?)",
        (data["username"], data["email"], pwd_hash, datetime.utcnow().isoformat()),
    )
    user_id = cur.lastrowid

    cur.execute(
        """INSERT INTO doctors (user_id, full_name, mcj_reg_no, phone, parish, office_address)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (
            user_id,
            data["full_name"],
            data["mcj_reg_no"],
            data.get("phone"),
            data.get("parish"),
            data.get("office_address"),
        ),
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "role": "doctor"})

# ---------- Universal Login ----------

@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    user_input = data.get("username") or data.get("email")
    pwd = data.get("password", "")

    if not user_input or not pwd:
        return jsonify({"error": "Missing credentials"}), 400

    conn = get_db()
    cur = conn.cursor()

    # 🔹 Check unified users table first
    cur.execute("SELECT * FROM users WHERE username=? OR email=?", (user_input, user_input))
    user_row = cur.fetchone()

    # 🔹 Fallback: legacy staff
    if not user_row:
        cur.execute("SELECT * FROM staff WHERE username=? OR email=?", (user_input, user_input))
        staff_row = cur.fetchone()
        if staff_row and bcrypt.checkpw(pwd.encode(), staff_row["password_hash"]):
            conn.close()
            return jsonify({"ok": True, "username": staff_row["username"], "role": "staff"})
        conn.close()
        return jsonify({"error": "Invalid username or password"}), 401

    # 🔹 Verify password
    if not bcrypt.checkpw(pwd.encode(), user_row["password_hash"]):
        conn.close()
        return jsonify({"error": "Invalid username or password"}), 401

    conn.close()
    return jsonify({"ok": True, "username": user_row["username"], "role": user_row["role"]})


# ---------- Application ----------
@app.post("/api/applications")
def create_application():
    data = request.get_json() or {}
    full_name = data.get("full_name")
    trn = data.get("trn")
    dob = data.get("dob")
    gender = data.get("gender")
    address = data.get("address")
    phone = data.get("phone")
    parish = data.get("parish")
    condition = data.get("condition")
    if not all([full_name, trn, dob, gender]):
        return jsonify({"error": "Missing required fields"}), 400

    code = generate_application_code()
    created_at = datetime.utcnow().isoformat()
    conn = get_db()
    cur = conn.cursor()

    attempts = 0
    while True:
        cur.execute("SELECT 1 FROM applications WHERE code=?", (code,))
        if not cur.fetchone():
            break
        code = generate_application_code()
        attempts += 1
        if attempts > 10:
            conn.close()
            return jsonify({"error": "Could not generate unique application code"}), 500

    try:
        cur.execute("""INSERT INTO applications(code, full_name, trn, dob, gender, address, phone, parish, condition, created_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (code, full_name, trn, dob, gender, address, phone, parish, condition, created_at))
        cur.execute("""INSERT INTO approvals(app_code, status) VALUES(?, 'pending')""", (code,))
        conn.commit()
    except sqlite3.IntegrityError as e:
        return jsonify({"error": "Application already exists", "details": str(e)}), 409
    finally:
        conn.close()
    return jsonify({"ok": True, "code": code})

# ---------- Certifications ----------
@app.post("/api/certifications")
def create_certification():
    import json as _json
    data = request.get_json(silent=True) or {}
    app_code = data.get("app_code") or data.get("code")
    doctor_name = data.get("doctor_name") or data.get("doctorName")
    mcj_reg_no = data.get("mcj_reg_no") or data.get("mcjRegNo")
    office_address = data.get("office_address")
    parish = data.get("parish")
    office_phone = data.get("office_phone")
    notes = data.get("notes")
    conditions = data.get("conditions") or data.get("condition")

    if isinstance(conditions, str):
        if conditions.strip().startswith("["):
            try:
                conditions = _json.loads(conditions)
            except Exception:
                pass
        else:
            conditions = [c.strip() for c in conditions.split(",") if c.strip()]
    if not isinstance(conditions, list):
        conditions = [conditions] if conditions else []

    if not app_code or not doctor_name or not mcj_reg_no:
        return jsonify({"error": "Missing required certification fields"}), 400

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT condition FROM applications WHERE code = ?", (app_code,))
    app_row = cur.fetchone()
    if not app_row:
        conn.close()
        return jsonify({"error": "Application not found"}), 404

    if not conditions and app_row["condition"]:
        conditions = [app_row["condition"]]

    certification_date = datetime.utcnow().date().isoformat()
    cur.execute("""INSERT INTO certifications(app_code, doctor_name, mcj_reg_no, office_address, parish, office_phone, conditions_json, notes, certification_date)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (app_code, doctor_name, mcj_reg_no, office_address, parish, office_phone, _json.dumps(conditions), notes, certification_date))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

# ---------- Staff ----------
@app.post("/api/staff/register")
def staff_register():
    data = request.get_json() or {}
    required = ["username", "email", "password", "dob", "gender", "trn", "staff_id"]
    if not all(data.get(k) for k in required):
        return jsonify({"error": "Missing required staff registration fields"}), 400
    if user_exists(data["username"], data["email"]):
        return jsonify({"error": "Account already exists with another role"}), 400
    pwd_hash = bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt())
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""INSERT INTO staff(username, email, password_hash, dob, gender, trn, staff_id)
                   VALUES(?,?,?,?,?,?,?)""",
                (data["username"], data["email"], pwd_hash, data["dob"], data["gender"], data["trn"], data["staff_id"]))
    cur.execute("INSERT INTO users(username, email, password_hash, role, created_at) VALUES (?, ?, ?, 'staff', ?)",
                (data["username"], data["email"], pwd_hash, datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "role": "staff"})

@app.post("/api/staff/approve")
def approve_application():
    data = request.get_json() or {}
    app_code = data.get("app_code")
    action = data.get("action")
    reviewer = data.get("reviewer_username", "staff")
    reason = data.get("reason")
    if action not in ("approved", "rejected") or not app_code:
        return jsonify({"error": "Invalid action"}), 400
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM applications WHERE code=?", (app_code,))
    app_row = cur.fetchone()
    if not app_row:
        conn.close()
        return jsonify({"error": "Application not found"}), 404
    cur.execute("""INSERT INTO approvals(app_code, status, reviewer_username, reviewed_at, reason)
                   VALUES(?,?,?,?,?)""",
                (app_code, action, reviewer, datetime.utcnow().isoformat(), reason))
    if action == "approved":
        member_number = app_code
        cur.execute("""INSERT OR IGNORE INTO members(member_number, full_name, trn, valid_from)
                       VALUES(?,?,?,?)""",
                    (member_number, app_row["full_name"], app_row["trn"], datetime.utcnow().date().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

# ---------- Barcode ----------
@app.get("/api/barcode/<nhf>")
def barcode(nhf):
    digits = "".join(ch for ch in str(nhf) if ch.isdigit())
    if len(digits) not in (12, 13):
        return jsonify({"error": "NHF number must contain 12 or 13 digits"}), 400
    ean = EAN13(digits, writer=ImageWriter())
    buf = BytesIO()
    ean.write(buf)
    buf.seek(0)
    return send_file(buf, mimetype="image/png", download_name=f"{digits}.png")

# ---------- Run ----------
if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
